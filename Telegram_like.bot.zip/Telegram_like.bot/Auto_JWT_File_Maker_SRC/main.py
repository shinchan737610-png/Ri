import json
import os
import requests
import re
import time
import io
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
from telegram.error import BadRequest

# --- CONFIGURATION ---
BOT_TOKEN = "8724800926:AAHd6VwJGXY2qaCwKePTHZJ53gbuAAcj1yE" 
API_BASE_URL = "https://only-jwt.vercel.app/token"

def fix_and_parse_json(raw_content):
    content = raw_content.strip()
    if not content.startswith('['):
        content = re.sub(r'}\s*{', '},{', content)
        content = f"[{content}]"
    content = re.sub(r',\s*([\]}])', r'\1', content)
    return json.loads(content)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🚀 **Bot Ready!**\nSend your JSON file to begin.")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.chat_id
    file = await update.message.document.get_file()
    temp_path = f"temp_{user_id}.json"
    await file.download_to_drive(temp_path)
    
    # Save path in user_data to access after button click
    context.user_data['file_path'] = temp_path

    # Show Mode Selection Buttons
    keyboard = [
        [
            InlineKeyboardButton("⚡ Fast (Good Net)", callback_data='mode_fast'),
            InlineKeyboardButton("🐢 Slow (Laggy Net)", callback_data='mode_slow')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("📶 **Select Processing Mode:**\nChoose based on your current internet speed.", reply_markup=reply_markup)

async def process_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    mode = query.data
    user_id = query.message.chat_id
    temp_input = context.user_data.get('file_path')

    if not temp_input or not os.path.exists(temp_input):
        await query.edit_message_text("❌ Error: File lost. Please resend it.")
        return

    # Set configuration based on mode
    if mode == 'mode_fast':
        gap, timeout, mode_name = 0.5, 15, "⚡ Fast Mode"
    else:
        gap, timeout, mode_name = 4, 60, "🐢 Slow Mode"

    await query.edit_message_text(f"⏳ **Starting {mode_name}...**")

    try:
        with open(temp_input, 'r', encoding='utf-8') as f:
            accounts = fix_and_parse_json(f.read())
        
        total = len(accounts)
        final_data, failed_data = [], []

        for index, acc in enumerate(accounts):
            uid, pwd = acc.get("uid"), acc.get("password")
            success = False
            status = "☁️ Processing"

            if uid and pwd:
                for attempt in range(2):
                    try:
                        res = requests.get(API_BASE_URL, params={"uid": uid, "password": pwd}, timeout=timeout)
                        if res.status_code == 200:
                            token = res.json().get("token")
                            if token:
                                final_data.append({"uid": str(uid), "token": token})
                                success, status = True, "✅ Success"
                                break
                    except:
                        status = "🔄 Retrying..."
                        time.sleep(1)

                if not success:
                    failed_data.append(acc)
                    status = "❌ Failed"

                # Update Progress
                curr = index + 1
                perc = int((curr / total) * 100)
                bar = "▓" * (perc // 10) + "░" * (10 - (perc // 10))
                msg = (f"⚙️ **{mode_name}**\n`[{bar}]` {perc}%\n"
                       f"📡 Status: `{status}`\n"
                       f"✅ Success: `{len(final_data)}` | 🗑️ Trash: `{len(failed_data)}` ")
                
                try: await query.edit_message_text(msg, parse_mode="Markdown")
                except: pass
                
                if curr < total: time.sleep(gap)

        # Send Files
        if final_data:
            f1 = io.BytesIO(json.dumps(final_data, indent=4).encode()); f1.name = "token_ind.json"
            await context.bot.send_document(chat_id=user_id, document=f1, filename="token_ind.json", caption="✅ Successful Tokens")
        
        if failed_data:
            f2 = io.BytesIO(json.dumps(failed_data, indent=4).encode()); f2.name = "trash_token.json"
            await context.bot.send_document(chat_id=user_id, document=f2, filename="trash_token.json", caption="🗑️ Trash Tokens")

    except Exception as e:
        await context.bot.send_message(chat_id=user_id, text=f"❌ Error: {str(e)}")
    finally:
        if os.path.exists(temp_input): os.remove(temp_input)

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(CallbackQueryHandler(process_choice))
    print("Bot with Fast/Slow options is running...")
    app.run_polling()
