import json
import os
import requests
import re
import time
import io
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler
from telegram.error import BadRequest

# --- CONFIGURATION ---
BOT_TOKEN = "8724800926:AAHd6VwJGXY2qaCwKePTHZJ53gbuAAcj1yE" 
API_BASE_URL = "https://only-jwt.vercel.app/token"

def fix_and_parse_json(raw_content):
    content = raw_content.strip()
    if not content.startswith('['):
        content = re.sub(r'}\s*{', '},{', content)
        content = f"[{content}]"
    content = re.sub(r',\s*([\]}])', r'\1', content)
    return json.loads(content)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🚀 **Bot Ready!**\nSend your JSON file to begin.")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.chat_id
    file = await update.message.document.get_file()
    
    # Save the original file content directly into memory
    file_bytes = await file.download_as_bytearray()
    raw_content = file_bytes.decode('utf-8')
    
    try:
        context.user_data['current_accounts'] = fix_and_parse_json(raw_content)
        await show_mode_selection(update.message, "📶 **File Received.** Select Mode:")
    except Exception as e:
        await update.message.reply_text(f"❌ **Invalid JSON:** {str(e)}")

async def show_mode_selection(message, text):
    keyboard = [[
        InlineKeyboardButton("⚡ Fast Mode", callback_data='mode_fast'),
        InlineKeyboardButton("🐢 Slow Mode", callback_data='mode_slow')
    ]]
    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    user_id = query.message.chat_id

    if data == 'stop_action':
        context.user_data['stop_process'] = True
        await query.answer("🛑 Stopping...")
        return

    if data == 're_execute_trash':
        # Replace current accounts with the trash list for the next run
        context.user_data['current_accounts'] = context.user_data.get('last_trash', [])
        await query.answer("🔄 Re-loading Trash...")
        await show_mode_selection(query.message, "🔄 **Retrying Trash Accounts.** Select Mode:")
        return

    # Start Processing
    await query.answer()
    accounts = context.user_data.get('current_accounts', [])
    context.user_data['stop_process'] = False
    
    if data == 'mode_fast':
        gap, timeout, mode_name = 0.8, 15, "⚡ Fast"
    else:
        gap, timeout, mode_name = 4, 60, "🐢 Slow"

    stop_kb = InlineKeyboardMarkup([[InlineKeyboardButton("🛑 STOP", callback_data='stop_action')]])
    status_msg = await query.edit_message_text(f"⏳ **Starting {mode_name}...**", reply_markup=stop_kb)

    final_data, failed_data = [], []
    total = len(accounts)

    for index, acc in enumerate(accounts):
        if context.user_data.get('stop_process'): break

        uid, pwd = acc.get("uid"), acc.get("password")
        success = False

        if uid and pwd:
            for attempt in range(2):
                try:
                    res = requests.get(API_BASE_URL, params={"uid": uid, "password": pwd}, timeout=timeout)
                    if res.status_code == 200:
                        token = res.json().get("token")
                        if token:
                            final_data.append({"uid": str(uid), "token": token})
                            success = True; break
                except: time.sleep(1)

            if not success: failed_data.append(acc)

            # Update UI
            curr = index + 1
            perc = int((curr / total) * 100)
            bar = "▓" * (perc // 10) + "░" * (10 - (perc // 10))
            msg = (f"⚙️ **Mode: {mode_name}**\n`[{bar}]` {perc}%\n"
                   f"✅ Success: `{len(final_data)}` | 🗑️ Trash: `{len(failed_data)}` ")
            
            try: await status_msg.edit_text(msg, reply_markup=stop_kb, parse_mode="Markdown")
            except: pass
            
            if curr < total: time.sleep(gap)

    # Save failures for potential re-execution
    context.user_data['last_trash'] = failed_data

    # Final Buttons
    final_kb = []
    if failed_data:
        final_kb.append([InlineKeyboardButton("🔄 Re-Execute Trash Only", callback_data='re_execute_trash')])
    
    await context.bot.send_message(
        chat_id=user_id, 
        text=f"🏁 **Finished!**\nSucceeded: `{len(final_data)}` | Failed: `{len(failed_data)}`", 
        reply_markup=InlineKeyboardMarkup(final_kb) if final_kb else None
    )

    # Deliver Files
    if final_data:
        f1 = io.BytesIO(json.dumps(final_data, indent=4).encode()); f1.name = "token_ind.json"
        await context.bot.send_document(chat_id=user_id, document=f1, filename="token_ind.json")
    
    if failed_data:
        f2 = io.BytesIO(json.dumps(failed_data, indent=4).encode()); f2.name = "trash_token.json"
        await context.bot.send_document(chat_id=user_id, document=f2, filename="trash_token.json")

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.run_polling()
