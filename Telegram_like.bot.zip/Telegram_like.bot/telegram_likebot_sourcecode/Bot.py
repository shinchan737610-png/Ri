import requests
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler

# --- CONFIGURATION ---
TOKEN = '8405749630:AAEhY3XZtdhVhIXRSEjwTn1PDRdWIFrOaW4'
GROUP_CHAT_ID = -1003719449540

# FIX: Only the base path goes here. The ?uid= part is added automatically below.
API_URL = "https://4like-api.vercel.app/like"

logging.basicConfig(level=logging.INFO)

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Check for: /like <UID> <REASON>
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usage: `/like <UID> <REASON>`", parse_mode='Markdown')
        return

    uid = context.args[0]
    reason = " ".join(context.args[1:])
    
    status_msg = await update.message.reply_text(f"⏳ Sending Like to UID: `{uid}`...")

    try:
        # This part 'adds' the ?uid= and &server_name= to your API_URL automatically
        params = {'uid': uid, 'server_name': 'ind'}
        
        # Adding headers to mimic your Chrome browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        }
        
        # The request becomes: https://4like-api.vercel.app
        response = requests.get(API_URL, params=params, headers=headers, timeout=30)
        
        data = response.json()

        # Extracting info from your API response
        name = data.get('PlayerName') or data.get('name') or "Unknown"
        before = data.get('LikesBefore') or data.get('before') or "0"
        after = data.get('LikesAfter') or data.get('after') or "0"

        report = (
            f"📊 *LIKE SUCCESSFUL*\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 *Name:* `{name}`\n"
            f"🆔 *UID:* `{uid}`\n"
            f"📝 *Reason:* `{reason}`\n"
            f"📉 *Before:* `{before}`\n"
            f"📈 *After:* `{after}`\n"
            f"━━━━━━━━━━━━━━━━━━━━"
        )
        
        await context.bot.send_message(chat_id=GROUP_CHAT_ID, text=report, parse_mode='Markdown')
        await status_msg.delete()

    except Exception as e:
        await status_msg.edit_text(f"❌ *Error:* {str(e)}")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler('like', like_command))
    print("🚀 Bot started in Termux. Ready for /like commands!")
    app.run_polling()
