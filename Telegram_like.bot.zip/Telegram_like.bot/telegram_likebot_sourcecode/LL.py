import requests
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# Replace with your actual token from @BotFather
BOT_TOKEN = "8694348379:AAHFmStA-arviNCAEWCbPYHoYL68vVvEkcc"

# Enable logging
logging.basicConfig(level=logging.INFO)

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Ensure a UID was provided
    if not context.args:
        await update.message.reply_text("❌ **Usage:** `/like 1240881981`", parse_mode='Markdown')
        return

    uid = context.args[0]
    # YOUR API URL
    api_url = f"https://bb-azure-two.vercel.app/like?uid={uid}&server_name=ind"

    # Status message
    status_msg = await update.message.reply_text("⏳ *Contacting the server...*", parse_mode='Markdown')

    try:
        # Call your Vercel API
        response = requests.get(api_url, timeout=30)
        data = response.json()

        # Parse API data
        nickname = data.get("PlayerNickname", "N/A")
        likes_sent = data.get("LikesGivenByAPI", 0)
        note = data.get("Note", "No info provided.")
        total_likes = data.get("LikesafterCommand", 0)

        # --- FINAL CONDITIONS ---

        # 1. INVALID UID (Nickname is N/A)
        if nickname == "N/A":
            result_text = (
                f"❌ **Invalid UID!**\n\n"
                f"The UID `{uid}` was not found on the IND server. Please verify the ID."
            )

        # 2. SUCCESS (Likes were given)
        elif likes_sent > 0:
            result_text = (
                f"✅ **Likes Sent Successfully!**\n\n"
                f"👤 **Name:** `{nickname}`\n"
                f"🆔 **UID:** `{uid}`\n"
                f"👍 **Added:** {likes_sent}\n"
                f"📈 **New Total:** {total_likes}"
            )

        # 3. ALREADY LIKED (Valid UID, but 0 likes added)
        elif nickname != "N/A" and likes_sent == 0:
            result_text = (
                f"ℹ️ **Already Liked!**\n\n"
                f"👤 **Name:** `{nickname}`\n"
                f"🆔 **UID:** `{uid}`\n"
                f"This account has already received likes recently."
            )

        # 4. API ERROR SAFETY NET
        else:
            result_text = "⚠️ **Server Error:** The API returned an unknown response."

        # Update the message with the result
        await status_msg.edit_text(result_text, parse_mode='Markdown')

    except Exception as e:
        await status_msg.edit_text(f"❌ **Connection Error:** Could not reach the API.\n`{str(e)}`", parse_mode='Markdown')

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("like", like_command))
    
    print("Bot is active. Use /like [UID] in Telegram.")
    app.run_polling()
