import telebot
import requests

# --- CONFIGURATION ---
BOT_TOKEN = '8694348379:AAHFmStA-arviNCAEWCbPYHoYL68vVvEkcc'

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['like'])
def handle_like(message):
    try:
        msg_parts = message.text.split()
        if len(msg_parts) < 2:
            bot.reply_to(message, "❌ **Usage:** `/like <UID>`")
            return

        uid = msg_parts[1]
        
        # --- NEW: Send a "Processing" message for slow networks ---
        processing_msg = bot.reply_to(message, "⏳ **Processing your request... Please wait.**")

        api_url = f"https://bb-azure-two.vercel.app/{uid}&server_name=ind"

        # --- NEW: Increased timeout to 60 seconds for slow networks ---
        try:
            response = requests.get(api_url, timeout=60)
        except requests.exceptions.Timeout:
            bot.edit_message_text("⏰ **Error:** Network is too slow. Request timed out.", 
                                  chat_id=message.chat.id, 
                                  message_id=processing_msg.message_id)
            return
        except requests.exceptions.RequestException:
            bot.edit_message_text("⚠️ **Error:** Connection failed. Check your Termux network.", 
                                  chat_id=message.chat.id, 
                                  message_id=processing_msg.message_id)
            return
        
        if response.status_code == 200:
            try:
                data = response.json()
            except:
                bot.edit_message_text("______________________________\nSᴇʀᴠᴇʀ Bᴜsʏ ᴏʀ Mᴀɪɴᴛᴇɴᴀɴᴄᴇ 😡\n______________________________", 
                                      chat_id=message.chat.id, 
                                      message_id=processing_msg.message_id)
                return

            status = data.get('status')
            nickname = str(data.get('PlayerNickname', 'N/A'))
            after = data.get('LikesafterCommand', 0)
            before = data.get('LikesbeforeCommand', 0)
            likes_given = data.get('LikesGivenByAPI', 0)
            
            # --- LOGIC ---
            if nickname == "N/A":
                response_msg = (
                    "______________________________\n"
                    "Iɴᴠᴀʟɪᴅ ᴜɪᴅ 😡🤬🤬\n"
                    "______________________________"
                )
            elif status == 1:
                response_msg = (
                    "______________________________\n"
                    "Lɪᴋᴇ sᴇɴᴛ sᴜᴄᴄᴇssғᴜʟʟʏ 🥳\n"
                    "______________________________\n"
                    f"Uid Name:- {nickname}\n"
                    f"UID:- {uid}\n"
                    f"AfterLike:- {after}\n"
                    f"BeforeLike:- {before}\n"
                    f"LikeGiven:- {likes_given}\n"
                    "______________________________"
                )
            elif status == 2 or likes_given == 0:
                response_msg = (
                    "______________________________\n"
                    "Tᴏᴅᴀʏ ʟɪᴍɪᴛ ɪs ᴏᴠᴇʀ 😡\n"
                    "Tʀʏ ᴀɢᴀɪɴ ᴛᴏᴍᴍᴏʀᴏᴡ \n"
                    "______________________________\n"
                    f"Uid Name:- {nickname}\n"
                    f"UID:- {uid}\n"
                    "______________________________"
                )
            else:
                response_msg = "⚠️ API Error: Status not recognized."

            final_output = (
                f"{response_msg}\n"
                "Tʜᴀɴᴋᴜ ғᴏʀ ᴜsɪɴɢ ʙᴏᴛ ❤❤\n"
                "______________________________"
            )
            
            # Update the processing message with the final result
            bot.edit_message_text(final_output, chat_id=message.chat.id, message_id=processing_msg.message_id)

        else:
            bot.edit_message_text("⚠️ API Error: Unable to reach server.", 
                                  chat_id=message.chat.id, 
                                  message_id=processing_msg.message_id)

    except Exception as e:
        bot.reply_to(message, f"❌ System Error: {str(e)}")

print("Bot is successfully running. Handling slow networks...")
bot.infinity_polling()
